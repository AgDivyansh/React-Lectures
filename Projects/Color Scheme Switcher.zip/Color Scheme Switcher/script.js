const box = document.querySelectorAll(".box") ;
const body = document.querySelector("body")
// console.log(box);


box.forEach(box => {
    // console.log(`this is a loop`);
    // console.log(`${box}`);
    box.addEventListener("click",(e) => {
    //   console.log(e);
    //   console.log(`${e.target}`);
    // console.log(ele);
    
    let idname = e.target.id ;
    console.log(`${idname}`);
    const ele = document.getElementById(idname)
    // console.log(ele);

    const styles = window.getComputedStyle(ele,null) ;

    body.style.backgroundColor = styles.backgroundColor ;
    
    
    })
});

console.log(`sab theek`) ;
